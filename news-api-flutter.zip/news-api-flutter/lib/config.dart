class Config{
  var apiKey = "6dcf3d1c32b840129a51ae0804107e7f";
  var urlApi = "https://newsapi.org/v2/";
}